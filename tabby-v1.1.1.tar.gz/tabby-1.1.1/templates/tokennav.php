	<div class="bg-danger text-white navbar-dark">
		<div class="container">
			
			<nav class="navbar px-0 navbar-expand-lg navbar-dark">
				<a class="navbar-brand text-chicle" href="#">
					<img src="tabby.png" width="30" height="30" class="d-inline-block align-top" alt=""> &nbsp; Tabby
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
					<div class="navbar-nav ml-auto">
						<a href="<?php echo $location; ?>?reset" class="p-3 text-decoration-none text-white">Reset unique token</a>
					</div>
				</div>
			</nav>

		</div>
	</div>