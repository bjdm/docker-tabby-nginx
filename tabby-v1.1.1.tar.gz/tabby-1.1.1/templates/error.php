	<div class="container pt-5 pb-3">
		<div class="row">
			<div class="col-md-6 offset-md-3">
				<div class="alert alert-danger" role="alert">
					<strong>Error</strong> <?php echo $error; ?>
				</div>
			</div>
		</div>
	</div>